import { useCallback, useEffect, useState } from "react";
import { api, unwrapList } from "../api/jobs";
import type { Job, Patch, WorkflowEvent } from "../api/types";

export function useJobDetails(id: string | undefined) {
  const [job, setJob] = useState<Job | null>(null);
  const [patch, setPatch] = useState<Patch | null>(null);
  const [events, setEvents] = useState<WorkflowEvent[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const refresh = useCallback(async () => {
    if (!id) { setError("No job ID was provided."); setLoading(false); return; }
    setLoading(true); setError("");
    try {
      const [j, p, ev] = await Promise.all([api.job(id), api.patch(id), api.events(id)]);
      setJob(j); setPatch(p); setEvents(unwrapList(ev, "events"));
    } catch (e) { setError(e instanceof Error ? e.message : "Unable to load investigation"); }
    finally { setLoading(false); }
  }, [id]);
  useEffect(() => { void refresh(); }, [refresh]);
  return { job, patch, events, loading, error, refresh, setJob, setPatch };
}