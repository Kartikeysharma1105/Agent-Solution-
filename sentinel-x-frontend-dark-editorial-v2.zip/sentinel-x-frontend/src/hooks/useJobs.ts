import { useCallback, useEffect, useState } from "react";
import { api, unwrapList } from "../api/jobs";
import type { Job } from "../api/types";

export function useJobs() {
  const [jobs, setJobs] = useState<Job[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const refresh = useCallback(async () => {
    setLoading(true); setError("");
    try { setJobs(unwrapList(await api.jobs(), "jobs")); }
    catch (e) { setError(e instanceof Error ? e.message : "Unable to load jobs"); }
    finally { setLoading(false); }
  }, []);
  useEffect(() => { void refresh(); }, [refresh]);
  return { jobs, loading, error, refresh };
}