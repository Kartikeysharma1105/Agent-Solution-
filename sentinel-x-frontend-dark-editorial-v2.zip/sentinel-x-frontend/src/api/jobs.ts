import { request } from "./client";
import type { Evidence, Finding, Job, Patch, VerificationResult, WorkflowEvent } from "./types";

export const api = {
  health: () => request<Record<string, unknown>>("/health"),
  createFinding: (payload: { target_app_id: string; finding: Finding }) =>
    request<Job | { job_id: string }>("/api/findings", { method: "POST", body: JSON.stringify(payload) }),
  jobs: () => request<Job[] | { jobs: Job[] }>("/api/jobs"),
  job: (id: string) => request<Job>(`/api/jobs/${encodeURIComponent(id)}`),
  patch: (id: string) => request<Patch>(`/api/jobs/${encodeURIComponent(id)}/patch`),
  approval: (id: string, patch_hash: string, decision: "APPROVE" | "REJECT") =>
    request<Job>(`/api/jobs/${encodeURIComponent(id)}/approval`, { method: "POST", body: JSON.stringify({ patch_hash, decision }) }),
  verify: (id: string) => request<VerificationResult>(`/api/jobs/${encodeURIComponent(id)}/verify`, { method: "POST" }),
  evidence: (id: string) => request<Evidence>(`/api/jobs/${encodeURIComponent(id)}/evidence`),
  events: (id: string) => request<WorkflowEvent[] | { events: WorkflowEvent[] }>(`/api/jobs/${encodeURIComponent(id)}/events`),
};
export function unwrapList<T>(data: T[] | Record<string, T[]> , key: string): T[] {
  if (Array.isArray(data)) return data;
  const list = data[key];
  return Array.isArray(list) ? list : [];
}