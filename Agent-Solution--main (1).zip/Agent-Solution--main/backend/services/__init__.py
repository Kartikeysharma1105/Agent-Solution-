"""Trusted integration adapters."""
